import os
import json  # Added to format the log metrics
import mysql.connector
from pyspark.sql import SparkSession
# Import the streaming listener classes
from pyspark.sql.streaming import StreamingQueryListener 
from pyspark.sql.functions import from_json, col, current_timestamp, when, from_unixtime, from_utc_timestamp
from pyspark.sql.types import StructType, StructField, StringType, FloatType, DecimalType

# ---------------------------------------------------------
# Define the performance log saver
# ---------------------------------------------------------
class PerformanceMetricsLogger(StreamingQueryListener):
    def onQueryStarted(self, event):
        print(f"Streaming query started: {event.id}")

    def onQueryProgress(self, event):
        # This executes automatically at the end of EVERY micro-batch
        progress = event.progress
        batch_duration_ms = progress.get('batchDuration', 0)
        
        # Define where you want to save the log file inside the container
        # Ensure this directory is mapped to a volume if you want to keep it on your host machine
        log_file_path = "/opt/bitnami/spark/app/checkpoints/pipeline_performance.log"
        
        # Extract the exact metrics we discussed
        metrics_summary = {
            "timestamp": progress.get('timestamp'),
            "batchId": progress.get('batchId'),
            "batchDuration_sec": batch_duration_ms / 1000.0,
            "numInputRows": progress.get('numInputRows'),
            "inputRowsPerSecond": progress.get('inputRowsPerSecond'),
            "processedRowsPerSecond": progress.get('processedRowsPerSecond'),
            "avgLag": progress.get('observedMetrics', {}).get('avgOffsetsBehindLatest', 0.0)
        }
        
        # Check against your custom latency warning thresholds
        if batch_duration_ms > 15000:
            metrics_summary["alert_level"] = "🚨 CRITICAL"
        elif batch_duration_ms > 5000:
            metrics_summary["alert_level"] = "⚠️ WARNING"
        else:
            metrics_summary["alert_level"] = "INFO"

        # Append the metrics cleanly as a single JSON line (JSON Lines format)
        try:
            with open(log_file_path, "a") as f:
                f.write(json.dumps(metrics_summary) + "\n")
        except Exception as e:
            print(f"Failed to write performance log: {str(e)}")

    def onQueryTerminated(self, event):
        print(f"Streaming query terminated: {event.id}")


# 1. Initialize Spark with Low-Throughput & Strict Memory Tweaks
spark = SparkSession.builder \
    .appName("IoT-Sensor-Stream") \
    .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.1") \
    .config("spark.driver.memory", "1g") \
    .config("spark.sql.shuffle.partitions", "1") \
    .config("spark.cleaner.periodicGC.interval", "1min") \
    .config("spark.sql.streaming.minBatchesToRetain", "2") \
    .config("spark.sql.streaming.stateStore.maintenanceInterval", "1min") \
    .getOrCreate()

# ---------------------------------------------------------
# NEW: Register the listener to start tracking immediately
# ---------------------------------------------------------
spark.streams.addListener(PerformanceMetricsLogger())


# 2. Define the Schema 
schema = StructType([
    StructField("sensor_id", StringType(), True),
    StructField("temperature", FloatType(), True),
    StructField("humidity", FloatType(), True),
    StructField("timestamp_raw", DecimalType(16,6), True) 
])

# 3. Read from Kafka
df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "kafka1:29092,kafka2:29092") \
    .option("subscribe", "sensor_data") \
    .option("startingOffsets", "latest") \
    .load()

# 4. Parse the JSON 'value' column
parsed_df = df.selectExpr("CAST(value AS STRING)") \
    .select(from_json(col("value"), schema).alias("data")) \
    .select("data.*")

processed_df = parsed_df.withColumn(
        "event_time", 
        from_utc_timestamp(from_unixtime(col("timestamp_raw")), "Africa/Cairo").cast("timestamp")
    ) \
    .withColumn("created_at", current_timestamp()) \
    .withColumn("status", 
        when((col("temperature") > 50) | (col("humidity") < 10), "Warning")
        .otherwise("Normal")
    )

# 5. Cast types and handle basic cleaning
cleaned_df = processed_df.selectExpr(
    "CAST(sensor_id AS STRING)",
    "CAST(temperature AS DOUBLE)",
    "CAST(humidity AS DOUBLE)",
    "CAST(status AS STRING)",
    "CAST(timestamp_raw AS DECIMAL(16, 6)) AS timestamp_raw",
    "CAST(event_time AS TIMESTAMP)"
).filter(
    "sensor_id IS NOT NULL AND temperature IS NOT NULL AND timestamp_raw IS NOT NULL"
).filter(
    "temperature > -50 AND temperature < 100"
).withWatermark("event_time", "2 minutes") \
 .dropDuplicates(["sensor_id", "timestamp_raw"])


# 6. Function to write raw stream micro-batches to MySQL (sensor_readings)
def write_to_mysql(target_df, batch_id):
    db_user = os.getenv("MYSQL_USER")
    db_pass = os.getenv("MYSQL_PASSWORD")
    db_name = os.getenv("MYSQL_DATABASE")
    
    # Right-sized batching natively optimized for ~10 records per execution
    target_df.write \
        .format("jdbc") \
        .option("url", f"jdbc:mysql://mysql:3306/{db_name}") \
        .option("dbtable", "sensor_readings") \
        .option("user", db_user) \
        .option("password", db_pass) \
        .option("batchsize", "50") \
        .mode("append") \
        .save()

# 7. Start the Streams
query_raw = cleaned_df.writeStream \
    .foreachBatch(write_to_mysql) \
    .trigger(processingTime='5 second') \
    .option("checkpointLocation", "/opt/bitnami/spark/app/checkpoints") \
    .start()

# Await termination across background streaming thread
spark.streams.awaitAnyTermination()