CREATE TABLE IF NOT EXISTS sensor_readings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sensor_id VARCHAR(50) NOT NULL,
    temperature FLOAT,
    humidity FLOAT,
    status VARCHAR(20),   
    timestamp_raw DECIMAL(16, 6) NOT NULL, 
    event_time TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    -- Deduplication logic: prevents same sensor from sending same time twice
    UNIQUE KEY unique_reading (sensor_id, timestamp_raw),
    -- Optimization for Power BI 
    INDEX idx_event_time (event_time)
);

CREATE TABLE IF NOT EXISTS hourly_sensor_aggregates (
    sensor_id VARCHAR(50),
    hour_bucket TIMESTAMP,
    avg_temp DOUBLE,
    max_temp DOUBLE,
    avg_hum DOUBLE,
    warning_pct DOUBLE,
    PRIMARY KEY (sensor_id, hour_bucket)
);