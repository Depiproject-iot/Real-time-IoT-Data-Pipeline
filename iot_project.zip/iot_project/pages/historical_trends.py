import streamlit as st
import pandas as pd
import mysql.connector
import plotly.express as px
import datetime
import random

# --- 1. Page Configuration ---
st.set_page_config(page_title="IoT Historical Trends", layout="wide")

# --- 2. Unified Connection Function ---
def get_connection():
    return mysql.connector.connect(
        host="localhost",
        user="sensor_user",
        password="sensor_password",
        database="iot_db",
        port=3306
    )

def get_fallback_mock_data(days):
    now = datetime.datetime.now()
    records = []
    sensors = ["sensor_01", "sensor_02", "sensor_03", "sensor_04", "sensor_05"]
    for i in range(days * 24): 
        time_step = now - datetime.timedelta(hours=i)
        for s in sensors:
            records.append({
                "sensor_id": s,
                "hour_bucket": time_step.strftime('%Y-%m-%d %H:00:00'),
                "avg_temp": random.uniform(22.0, 27.0),
                "max_temp": random.uniform(27.0, 31.0),
                "avg_hum": random.uniform(40.0, 60.0),
                "warning_pct": random.uniform(0.0, 4.5)
            })
    return pd.DataFrame(records)

# --- 3. Main Dashboard Section ---
st.title("📜 Deep-Dive Historical Analytics")

# --- Sidebar Filters ---
st.sidebar.header("Filter History Settings")
days_to_look_back = st.sidebar.slider("Days to look back", 1, 4, 2)

# Dynamic Sensor Dropdown List
try:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT DISTINCT sensor_id FROM sensor_readings")
    sensor_list = [row[0] for row in cursor.fetchall()]
    cursor.close()
    conn.close()
except:
    sensor_list = ["sensor_01", "sensor_02", "sensor_03", "sensor_04", "sensor_05"]

sensor_list.insert(0, "All Sensors")
selected_sensor = st.sidebar.selectbox("Select Sensor ID", sensor_list)

# Build SQL query dynamically based on dropdown selection
sensor_filter_clause = ""
if selected_sensor != "All Sensors":
    sensor_filter_clause = f"AND sensor_id = '{selected_sensor}'"

# Query an aggregated OLAP table rather than a raw OLTP transactional table
query = f"""
SELECT 
    sensor_id, 
    hour_bucket,
    avg_temp,
    max_temp,
    avg_hum,
    warning_pct
FROM hourly_sensor_aggregates
WHERE hour_bucket >= DATE_SUB(NOW(), INTERVAL {days_to_look_back} DAY)
{sensor_filter_clause}
ORDER BY hour_bucket ASC
"""

try:       
    conn = get_connection()
    hist_df = pd.read_sql(query, conn)
    
    using_mock = False
    if hist_df.empty:
        hist_df = get_fallback_mock_data(days_to_look_back)
        if selected_sensor != "All Sensors":
            hist_df = hist_df[hist_df['sensor_id'] == selected_sensor]
        using_mock = True
        st.warning("⚠️ **Database is empty.** Displaying sandbox preview data below.")

    # --- KPI Alert Metrics ---
    overall_avg_temp = hist_df['avg_temp'].mean()
    overall_max_temp = hist_df['max_temp'].max()
    overall_avg_hum = hist_df['avg_hum'].mean()
    overall_warning_pct = hist_df['warning_pct'].mean()

    st.subheader("🎯 Period Performance Summary")
    kpi1, kpi2, kpi3, kpi4 = st.columns(4)  

    if overall_avg_temp > 30.0:
        kpi1.metric("Avg Temperature", f"{overall_avg_temp:.2f} °C", delta="🚨 CRITICAL HIGH", delta_color="inverse")
    elif overall_avg_temp < 20.0:
        kpi1.metric("Avg Temperature", f"{overall_avg_temp:.2f} °C", delta="❄️ COOL ENVIRONMENT", delta_color="normal")
    else:
        kpi1.metric("Avg Temperature", f"{overall_avg_temp:.2f} °C", delta="✅ OPTIMAL TEMP", delta_color="normal")

    if overall_max_temp >= 50.0:
        kpi2.metric("Max Recorded Peak", f"{overall_max_temp:.1f} °C", delta="🔥 WARNING: SPIKE DETECTED", delta_color="inverse")
    else:
        kpi2.metric("Max Recorded Peak", f"{overall_max_temp:.1f} °C", delta="✅ WITHIN SAFE BOUNDS", delta_color="normal")

    kpi3.metric("Avg Humidity Baseline", f"{overall_avg_hum:.1f} %", delta="📊 SYSTEM STABLE")

    if overall_warning_pct > 10.0:
        kpi4.metric("Warning Status Rate", f"{overall_warning_pct:.2f}%", delta="🚨 SLA BREACH: HIGH FAILURES", delta_color="inverse")
    elif overall_warning_pct > 2.0:
        kpi4.metric("Warning Status Rate", f"{overall_warning_pct:.2f}%", delta="⚠️ ELEVATED ANOMALIES", delta_color="inverse")
    else:
        kpi4.metric("Warning Status Rate", f"{overall_warning_pct:.2f}%", delta="🟢 STABLE (<2.0%)", delta_color="normal")

    # --- Historical Temperature Trend Chart ---
    st.markdown("---")
    st.subheader(f"📈 Hourly Temperature Trends ({selected_sensor})")
    
    if selected_sensor == "All Sensors":
        # Multi-line chart separating sensors cleanly by color channel
        fig = px.line(
            hist_df, 
            x='hour_bucket', 
            y='avg_temp', 
            color='sensor_id',
            facet_row='sensor_id', # Splits each sensor into its own horizontal row
            title="Hourly Average Temperature Trends (All Sensors)",
            labels={'hour_bucket': 'Time (Hourly Buckets)', 'avg_temp': 'Avg Temp (°C)', 'sensor_id': 'Sensor ID'}
        )
        fig.update_traces(mode='lines+markers')
    else:
        # Single sensor view: Filled area chart tracking a single metric trace
        fig = px.bar(
            hist_df, 
            x='hour_bucket', 
            y='avg_temp',
            title=f"Hourly Average Temperature Trend for {selected_sensor}",
            labels={'hour_bucket': 'Time (Hourly Buckets)', 'avg_temp': 'Avg Temp (°C)'},
            color_discrete_sequence=['#FF4B4B']
        )
        
    # Chart aesthetics configuration
    fig.update_layout(
        hovermode="x unified",
        margin=dict(l=20, r=20, t=50, b=20)
    )
    st.plotly_chart(fig, use_container_width=True)

    # --- Dataset Aggregation Summary Section at the Bottom ---
    st.markdown("---")
    st.subheader("📊 Dataset Aggregation Summary")
    
    col1, col2, col3 = st.columns(3)
    col1.write(f"**Filtered Profile:** `{selected_sensor}`")
    col2.write(f"**Total Hourly Aggregates Evaluated:** `{len(hist_df)}`")
    col3.write(f"**Overall Warning Rate:** `{overall_warning_pct:.2f}%`")

    conn.close()
        
except Exception as e:
    st.error(f"Execution error parsing file parameters: {e}")