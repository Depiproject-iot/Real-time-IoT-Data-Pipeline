import os
import time
import mysql.connector

def run_offline_aggregation():
    db_host = "mysql"
    db_user = os.getenv("MYSQL_USER")
    db_pass = os.getenv("MYSQL_PASSWORD")
    db_name = os.getenv("MYSQL_DATABASE")

    try:
        conn = mysql.connector.connect(host=db_host, user=db_user, password=db_pass, database=db_name)
        cursor = conn.cursor()

        # SQL Query that mimics exact Spark window logic.
        # It scans data from the last 3 hours to safeguard against mid-hour restarts or pipeline downtime.
        aggregation_query = """
        INSERT INTO hourly_sensor_aggregates (sensor_id, hour_bucket, avg_temp, max_temp, avg_hum, warning_pct)
        SELECT 
            sensor_id,
            DATE_FORMAT(event_time, '%Y-%m-%d %H:00:00') AS hour_bucket,
            AVG(temperature) AS avg_temp,
            MAX(temperature) AS max_temp,
            AVG(humidity) AS avg_hum,
            (SUM(CASE WHEN status = 'Warning' THEN 1 ELSE 0 END) / COUNT(*)) * 100 AS warning_pct
        FROM 
            sensor_readings
        WHERE 
            event_time >= NOW() - INTERVAL 3 HOUR
        GROUP BY 
            sensor_id, 
            DATE_FORMAT(event_time, '%Y-%m-%d %H:00:00')
        ON DUPLICATE KEY UPDATE 
            avg_temp = VALUES(avg_temp),
            max_temp = VALUES(max_temp),
            avg_hum = VALUES(avg_hum),
            warning_pct = VALUES(warning_pct);
        """
        
        print("Executing offline historical aggregation for the last 3 hours...")
        cursor.execute(aggregation_query)
        conn.commit()
        print(f"Aggregation complete. Affected rows: {cursor.rowcount}")

    except mysql.connector.Error as err:
        print(f"Database error during offline aggregation: {err}")
    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()

if __name__ == "__main__":
    print("Historical aggregator service initialized.")
    while True:
        run_offline_aggregation()
        print("Sleeping for 20 minutes...")
        time.sleep(1200) # Run every 20 minutes