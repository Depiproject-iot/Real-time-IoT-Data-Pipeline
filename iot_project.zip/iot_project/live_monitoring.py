import streamlit as st
import plotly.express as px
import pandas as pd
import mysql.connector
import time

# --- 1. Page Configuration ---
st.set_page_config(page_title="IoT Live Monitoring", layout="wide")

# --- 2. Unified Connection Function ---
def get_connection():
    return mysql.connector.connect(
        host="localhost",
        user="sensor_user",
        password="sensor_password",
        database="iot_db",
        port=3306
    )

# --- 3. Data Fetching Functions ---
def get_live_data():
    try:
        conn = get_connection()
        # Pull by a strict time window (e.g., last 5 minutes) 
        # instead of an expensive, unbounded sorting LIMIT.
        query = """
        SELECT sensor_id, event_time, created_at, temperature, humidity, status 
        FROM sensor_readings 
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)
        """
        df = pd.read_sql(query, conn)
        conn.close()
        return df
    except Exception as e:
        st.error(f"Database error: {e}")
        return pd.DataFrame()
    
def get_total_records():
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM sensor_readings")
        total = cursor.fetchone()[0]
        cursor.close()
        conn.close()
        return total
    except:
        return 0

# --- 4. Sidebar Global Statistics ---
total_db_count = get_total_records()
st.sidebar.header("📊 Global Pipeline Statistics")
st.sidebar.metric("Total Records in DB", f"{total_db_count:,}")
st.sidebar.markdown("---")

# --- 5. Fetch Active Stream ---
df = get_live_data()

if not df.empty:
    # Process Timestamps and Calculate Latency early
    df['created_at'] = pd.to_datetime(df['created_at'])
    df['event_time'] = pd.to_datetime(df['event_time'])
    df['latency_sec'] = (df['created_at'] - df['event_time']).dt.total_seconds()

    # Sort chronological (oldest first in the batch) to count upwards properly
    df = df.sort_values('created_at', ascending=True)
    df['batch_warning_count'] = (df['status'] == 'Warning').cumsum()
    # Re-sort descending so the newest records stay at the very top of your data tables
    df = df.sort_values('created_at', ascending=False)

    # --- Sidebar Individual Sensor Filter (CREATED ONCE) ---
    st.sidebar.header("Filter Real-Time Feed")
    sensor_options = list(df['sensor_id'].unique())
    sensor_options.sort()
    sensor_options.insert(0, "All Sensors")
    selected_sensor = st.sidebar.selectbox("Choose Target Sensor", sensor_options)

    # Filter dataframe based on user choice
    if selected_sensor != "All Sensors":
        df = df[df['sensor_id'] == selected_sensor]

    # --- Main Page Content ---
    st.title(f"🔴 Real-Time Feed ({selected_sensor})")
    live_placeholder = st.empty()

    with live_placeholder.container():
        # Sensor Performance Metrics Row
        st.subheader("📡 Core Sensor Metrics")
        m1, m2, m3 = st.columns(3)
        m1.metric("Avg Temperature", f"{df['temperature'].mean():.2f} °C")
        m2.metric("Max Humidity", f"{df['humidity'].max():.1f} %")
        m3.metric("Current Window Batch Size", len(df))

        # ------------------------------------------------------------------
        # ⏱️ Data Pipeline Latency Performance Layer
        # ------------------------------------------------------------------
        st.subheader("⏱️ Data Pipeline Latency Performance")
        
        # Calculate the smoothed 3-minute moving average across the active DataFrame
        three_minutes_ago = pd.Timestamp.now() - pd.Timedelta(minutes=3)
        recent_df = df[df['created_at'] >= three_minutes_ago]
        
        if not recent_df.empty:
            moving_avg_latency = recent_df['latency_sec'].mean()
        else:
            moving_avg_latency = df['latency_sec'].mean()

        latest_latency = df['latency_sec'].iloc[0] if not df.empty else 0.0
        peak_p99_latency = df['latency_sec'].quantile(0.99)

        l1, l2, l3 = st.columns(3)
        
        if moving_avg_latency > 15.0:
            l1.metric(
                label="3-Min Moving Average Latency", 
                value=f"{moving_avg_latency:.2f} s", 
                delta=f"🚨 SLA BREACH (Current: {latest_latency:.1f}s)", 
                delta_color="inverse"
            )
            st.error(
                f"🚨 **CRITICAL BACKLOG ALERT**\n\n"
                f"The pipeline's moving average latency has been sustained at **{moving_avg_latency:.2f}s** "
                f"over the last 3 minutes. The pipeline queue is experiencing heavy backpressure."
            )
        elif moving_avg_latency > 5.0:
            l1.metric(
                label="3-Min Moving Average Latency", 
                value=f"{moving_avg_latency:.2f} s", 
                delta=f"⚠️ ELEVATED (Current: {latest_latency:.1f}s)", 
                delta_color="inverse"
            )
            st.warning(
                f"⚠️ **SUSTAINED LATENCY WARNING**\n\n"
                f"Pipeline latency is averaging **{moving_avg_latency:.2f}s** over a 3-minute window. "
                f"Micro-batches are exceeding your Spark trigger interval framework."
            )
        else:
            l1.metric(
                label="3-Min Moving Average Latency", 
                value=f"{moving_avg_latency:.2f} s", 
                delta=f"🟢 STABLE (Current: {latest_latency:.1f}s)", 
                delta_color="normal"
            )
            
        l2.metric("99th Percentile Peak (p99)", f"{peak_p99_latency:.2f} s", help="Maximum processing time registered inside the current execution trace.")
        l3.metric("Instantaneous Latest Latency", f"{latest_latency:.2f} s", help="The raw processing time of the absolute newest row landing in the database.")

        # --- Render a Clean Timeline Distribution Chart ---
        latency_df = df.copy()
        
        fig_lat = px.area(
            latency_df,
            x='created_at',
            y='latency_sec',
            color='sensor_id',
            title="End-to-End Pipeline Latency Timeline (s)",
            labels={'created_at': 'System Ingestion Time', 'latency_sec': 'Duration (Seconds)'},
            color_discrete_sequence=px.colors.sequential.Tealgrn
        )
        
        fig_lat.update_layout(
            hovermode="x unified",
            margin=dict(l=20, r=20, t=40, b=20),
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
        )
        st.plotly_chart(fig_lat, use_container_width=True)

        # --- Core Data Visualizations Row ---
        st.markdown("---")
        st.subheader("Temperature Values Over Time")
        t_chart = df.pivot_table(index='created_at', columns='sensor_id', values='temperature')
        st.line_chart(t_chart)

        # --- Latest Stream Output Table ---
        st.subheader("Latest Stream Output")
        
        # Function to style columns when an alert status occurs
        def highlight_alert_columns(row):
            styles = [''] * len(row)
            sid_idx = row.index.get_loc('sensor_id')
            temp_idx = row.index.get_loc('temperature')            
            status_idx = row.index.get_loc('status')
            count_idx = row.index.get_loc('batch_warning_count')
            
            if row['status'] == 'Warning':
                alert_style = 'color: #FF4B4B; font-weight: bold;'
                styles[sid_idx] = alert_style
                styles[temp_idx] = alert_style
                styles[status_idx] = alert_style
                styles[count_idx] = alert_style
            return styles

        columns_to_show = ['sensor_id', 'created_at', 'temperature', 'humidity', 'status', 'batch_warning_count', 'latency_sec']
        styled_df = df[columns_to_show].head(20).style.apply(highlight_alert_columns, axis=1)
        
        st.dataframe(styled_df, use_container_width=True)
        
        # Safe trigger loop refresh 
        time.sleep(5)
        st.rerun()
else:
    st.warning("Waiting for streaming pipeline data...")
    time.sleep(2)
    st.rerun()