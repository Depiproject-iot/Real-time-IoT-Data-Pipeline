import json
import time
import random
import os
import csv
from multiprocessing import Process
from confluent_kafka import Producer

class IoTSensor:
    def __init__(self, sensor_id, sensor_type):
        self.sensor_id = sensor_id
        self.sensor_type = sensor_type
        self.base_temp = 25.0
        self.base_hum = 50.0

    def generate_data(self):
        # 5% chance of an outlier
        if random.random() < 0.05:
            temperature = random.uniform(80.0, 100.0)
            humidity = random.uniform(0.0, 10.0)
            #status = "warning" 
        else:
            temperature = self.base_temp + random.uniform(-2.0, 2.0)
            humidity = self.base_hum + random.uniform(-5.0, 5.0)
            #status = "normal"

        return {
            "sensor_id": self.sensor_id,
            "timestamp_raw": time.time(), # Changed key name to match SQL/Spark
            "temperature": round(temperature, 2), # Removed nested "data" dict
            "humidity": round(humidity, 2)
            }

def delivery_report(err, msg):
    if err is not None:
        print(f"Delivery failed: {err}")
    else:
        # Decode the message
        data = json.loads(msg.value().decode('utf-8'))        
        print(f"[{data['sensor_id']}] Temp: {data['temperature']}°C | Partition: {msg.partition()}")

def run_sensor_instance(s_id, s_type, log_file):
    """Function that runs as a separate process for each sensor"""
    conf = {
        'bootstrap.servers': 'kafka1:29092,kafka2:29092',
        'linger.ms': 10,           # Wait up to 10ms to batch metrics together
        'batch.num.messages': 500, # Group up to 500 records before shipping
        'compression.type': 'gzip' # Drastically reduces network payload size
    }
    producer = Producer(conf)
    sensor = IoTSensor(s_id, s_type)    
    
    print(f"Starting instance for {s_id}...")
    
    try:
        while True:
            
            # Generate data 
            payload = sensor.generate_data()
            # 1. Save to Local Data Log (CSV)            
            with open(log_file, 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    payload['sensor_id'], 
                    payload['timestamp_raw'], 
                    payload['temperature'], 
                    payload['humidity']
                ])
                
            # 2. Produce to Kafka           
            producer.produce(
                'sensor_data', 
                key=payload['sensor_id'], 
                value=json.dumps(payload),
                callback=delivery_report
                )
            producer.poll(0)
            time.sleep(random.uniform(2, 4)) # randomized to prevent 'clumping'
    except KeyboardInterrupt:
        pass
    finally:
        producer.flush()

if __name__ == "__main__":
    
    # --- LOGGING CONFIGURATION ---
    
    log_folder = "logs"
    os.makedirs(log_folder, exist_ok=True)
    log_file = os.path.join(log_folder, "sensor_data_log.csv")    
    
    if not os.path.exists(log_file):
        with open(log_file, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["sensor_id", "timestamp_raw", "temperature", "humidity"])
            
    # Define your list of sensors here
    sensor_list = [
        ("sensor_01", "Industrial"),
        ("sensor_02", "Industrial"),
        ("sensor_03", "Environmental"),
        ("sensor_04", "Environmental"),
        ("sensor_05", "Outdoor")
    ]

    processes = []

    print(f"Launching {len(sensor_list)} sensors... Press Ctrl+C to stop all.")

    for s_id, s_type in sensor_list:
        p = Process(target=run_sensor_instance, args=(s_id, s_type, log_file))
        p.start()
        processes.append(p)

    try:
        for p in processes:
            p.join()
    except KeyboardInterrupt:
        print("\nShutting down all sensors...")